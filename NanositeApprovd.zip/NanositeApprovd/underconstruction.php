<?php

require_once 'header.php';

echo <<<_END

<html>
    <body>
        <div class='center'>This page is under construction.<br><br>
            Good stuff coming soon.<br><br>
        </div>
        <div class='center'>
            <a data-role='button' data-inline='true' data-icon='check'
            data-transition="slide" href='index.php'>Home</a>
        </div>
  </body>
</html>
_END;

?>