<?php // index.php
  session_start();
require_once 'header.php';

echo <<<_END

<div id="page-container">
    </div>
    <div class='center'>
      <footer id="footer">Jolene Lozow MSSE 661 2019</footer>
    </div>
  </body>
</html>
_END;
?>
