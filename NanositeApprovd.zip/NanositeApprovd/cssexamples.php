<?php
echo <<<_INIT
<!DOCTYPE html> 
<head>
    <link rel='stylesheet' href='styles.css' type='text/css'>
</head>
<div class='center>
    <body class='body'>body</body>
    <h1>h1</h1>
    <h2>h2</h2>
    <a>a</a>
</div>
</html>
_INIT
?>

